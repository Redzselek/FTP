<?php
include 'dbconn.php'; // itt hivatkozol a fent létrehozott adatbázis kapcsolatot tartalmazó fájlra

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // formgyak táblába kerülő adatok
    $vezeteknev = $_POST['vezeteknev'];
    $keresztnev = $_POST['keresztnev'];
    $email = $_POST['email'];
    $jelszo = $_POST['jelszo'];
    $eletkor = $_POST['eletkor'];
    $nem = $_POST['nem'];

    $foci = isset($_POST['foci']) ? 1 : 0;
    $kosar = isset($_POST['kosar']) ? 1 : 0;
    $anime = isset($_POST['anime']) ? 1 : 0;

    // formgyak_varos táblába kerülő adatok
    $varos = $_POST['varos'];
    $irszam = $_POST['irszam'];
    $utca = $_POST['utca'];
    $hsz = $_POST['hsz'];

    // Adatok beszúrása az "formgyak" táblába
    $sql1 = "INSERT INTO formgyak (vezeteknev, keresztnev, email, jelszo, eletkor, nem, foci, kosar, anime)
            VALUES ('$vezeteknev', '$keresztnev', '$email', '$jelszo', $eletkor, $nem, $foci, $kosar, $anime)";
    
    // Adatok beszúrása az "formgyak_varos" táblába
    $sql2 = "INSERT INTO formgyak_varos (varos, irszam, utca, hsz)
            VALUES ('$varos', $irszam, '$utca', $hsz)";

    if ($conn->query($sql1) === TRUE && $conn->query($sql2) === TRUE) {
        echo "Az adatok sikeresen feltöltve.";
    } else {
        echo "Hiba történt: " . $conn->error;
    }

    $conn->close();
    header("Location: form.php");
}
?>
