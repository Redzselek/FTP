<?php
require("dbconn.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); 
if(isset($_GET["id"]) )
{
    $torol = "DELETE FROM formgyak WHERE id = {$_GET['id']}  ";
    mysqli_query($conn, $torol);
    $torol2 = "DELETE FROM formgyak_varos WHERE id = {$_GET['id']}  ";
    mysqli_query($conn, $torol2);
    header("Location: form-keker.php");
}