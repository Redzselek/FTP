<?php
$servername = "localhost";
$username = "egyedirobi";
$password = "thisIsMor1czCloudMF!?";
$database = "egyedirobi_wp";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed");
}
?>