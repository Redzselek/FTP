<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adatfeltöltés</title>
    <style>
        form {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background-color: #f2f2f2;
            border: 2px solid #ccc;
            border-radius: 5px;
            box-shadow: 5px 5px 10px rgba(0,0,0,0.1);
        }

        label {
            display: block;
            margin: 10px 0;
        }

        input[type="text"], input[type="email"], input[type="password"], input[type="number"] {
            width: 95%;
            padding: 10px;
            margin-bottom: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            scale: 1.0;
            transition: 0.25s ease-in-out;
        }

        input[type="submit"]:hover {
            background-color: #45a521;
            scale: 1.2;
            transition: 0.25s ease-in-out;
        }

        .listaGomb {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            scale: 1.0;
            transition: 0.25s ease-in-out;
        }

        .listaGomb:hover {
            background-color: #45a521;
            scale: 1.2;
            transition: 0.25s ease-in-out;
        }

        @media only screen and (max-width: 768px) {
            form {
                width: 100%;
            }
        }

        @media only screen and (min-width: 768px) {
            form {
                width: 80%;
            }
        }    
</style>
</head>
<body>

<h2>Felhasználói adatok</h2>
<form action="form-w.php" method="POST">
    <label for="vezeteknev">Vezetéknév:</label><br>
    <input type="text" id="vezeteknev" name="vezeteknev" maxlength="30" required><br>

    <label for="keresztnev">Keresztnév:</label><br>
    <input type="text" id="keresztnev" name="keresztnev" maxlength="30" required><br>

    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email" maxlength="40" required><br>

    <label for="jelszo">Jelszó:</label><br>
    <input type="password" id="jelszo" name="jelszo" maxlength="28" required><br>

    <label for="eletkor">Életkor:</label><br>
    <input type="number" id="eletkor" name="eletkor" required><br>

    <p style="text-align: center;">
        <label for="nem">Nem:</label>
        <input type="radio" id="ferfi" name="nem" value="1" required style="margin-right: 15px;"> Férfi
        <input type="radio" id="no" name="nem" value="0" required> Nő
    </p>
    <p style="text-align: center;">
        <label for="foci" style="display: inline-block; margin-right: 10px;">Foci:<input type="checkbox" id="foci" name="foci" value="1"></label>
        <label for="kosar" style="display: inline-block; margin-right: 10px;">Kosárlabda:<input type="checkbox" id="kosar" name="kosar" value="1"></label>
        <label for="anime" style="display: inline-block; margin-right: 10px;">Anime: <input type="checkbox" id="anime" name="anime" value="1"></label>
        <br>
    </p>

    <h3>Lakhely adatok</h3>

    <label for="varos">Város:</label>
    <input type="text" id="varos" name="varos" maxlength="20" required><br>

    <label for="irszam">Irányítószám:</label>
    <input type="number" id="irszam" name="irszam" required><br>

    <label for="utca">Utca:</label>
    <input type="text" id="utca" name="utca" maxlength="20" required><br>

    <label for="hsz">Házszám:</label>
    <input type="number" id="hsz" name="hsz" required><br><br>

    <input type="submit" value="Küldés">
    <a class="listaGomb" href="form-leker.php">Lista a felhasználókról</a>
</form>
</body>
</html>

