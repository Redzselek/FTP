<?php 
include 'dbconn.php';

$sql = "SELECT vezeteknev, keresztnev, email, eletkor, nem, foci, kosar, anime FROM formgyak";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Vezetéknév: " . $row["vezeteknev"]. " - Kereszt név: " . $row["keresztnev"]. " - e-mail: " . $row["email"]. " - életkor: " . $row["eletkor"]. " - Nem: " . $row["nem"]. "<br>";
        if($row["foci"] == 1) echo "Foci: igen <br>";
        if($row["kosar"] == 1) echo "Kosárlabda: igen <br>";
        if($row["anime"] == 1) echo "Anime: igen <br>";
        echo "<a href='form-torol.php?id=" . $row['id'] . "'>Törlés</a><br>";
        echo "<hr>";
    }
} else {
    echo "Nincsenek még felvitt adatok.";
}
$conn->close();
