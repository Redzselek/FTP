<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VizsgaLevel extends Model
{
    protected $table = 'level';
    protected $primaryKey = 'id';
    public $timestamps = true;
}